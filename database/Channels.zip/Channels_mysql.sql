CREATE DATABASE IF NOT EXISTS `CHANNELS` DEFAULT CHARACTER SET UTF8MB4 COLLATE utf8_general_ci;
USE `CHANNELS`;

CREATE TABLE `CHANNEL` (
  `id_channel` VARCHAR(42),
  `name_channel` VARCHAR(42),
  PRIMARY KEY (`id_channel`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `IS_IN_CHANNEL` (
  `nickname_user` VARCHAR(42),
  `id_channel` VARCHAR(42),
  `is_admin` VARCHAR(42),
  PRIMARY KEY (`nickname_user`, `id_channel`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `MESSAGE` (
  `id_message` VARCHAR(42),
  `time_message` VARCHAR(42),
  `id_channel` VARCHAR(42),
  `nickname_user` VARCHAR(42),
  PRIMARY KEY (`id_message`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `USER` (
  `nickname_user` VARCHAR(42),
  `password_user` VARCHAR(42),
  PRIMARY KEY (`nickname_user`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

ALTER TABLE `IS_IN_CHANNEL` ADD FOREIGN KEY (`id_channel`) REFERENCES `CHANNEL` (`id_channel`);
ALTER TABLE `IS_IN_CHANNEL` ADD FOREIGN KEY (`nickname_user`) REFERENCES `USER` (`nickname_user`);
ALTER TABLE `MESSAGE` ADD FOREIGN KEY (`nickname_user`) REFERENCES `USER` (`nickname_user`);
ALTER TABLE `MESSAGE` ADD FOREIGN KEY (`id_channel`) REFERENCES `CHANNEL` (`id_channel`);